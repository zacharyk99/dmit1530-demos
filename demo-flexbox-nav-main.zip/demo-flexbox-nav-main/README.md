# [demo] Flexbox Nav

Create simple navigation using flexbox container properties of focusing on the main and cross axes.
